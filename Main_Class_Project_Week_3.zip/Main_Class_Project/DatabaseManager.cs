public class DatabaseManager
{
    private string ConnectTo; //Researching this step, but will need to connect to SQLite db 

    public void InitializeDb() //Create table in SQLite if the table does not already exist
    {
        ;
    } 

    public string InsertItem() //Should add item ID to the database... serves as PrimaryKey (PK) 
    {
        ;
    }

    public string UpdateItem() //Modify items in database
    {
        ;
    }

    public string DeleteItem() //Delete an item from the table
    {
        ;
    }

    public string GetAllItems() //Query table in db to get all items (select * from table)
    {
        ;
    }

}