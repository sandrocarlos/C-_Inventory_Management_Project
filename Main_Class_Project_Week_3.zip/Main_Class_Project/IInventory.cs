interface IInventory
{
    int ItemID;

    string InventoryStatus(); //Displays a message if inventory is well stocked or if items need to be ordered

    public override string ToString()
    {
        ;
    }
}