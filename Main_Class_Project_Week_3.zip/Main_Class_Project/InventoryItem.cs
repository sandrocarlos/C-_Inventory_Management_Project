/*****

Project header


******/
using System;
public class InventoryItem : IInventory
{
	public int ItemID {get; set;} //Unique identifier (will be PK for database)
	public string ItemName {get; set;} //Part name 
    public string ItemCategory {get; set;} //Category of item such as Laptop, Desktop, GPU, Power Supply etc.
    public int ItemQuantity {get; set;} //How many are on hand

    // public double ItemPrice {get; set;}  //The application is more so of an inventory manager, not to browse 
                                            // and shop... this may change through the life of the project
    public string ItemDescription {get; set;} //Brief description of the item
    public DateTime LastUpdated {get; set;} //Will call DateTime.Now to set the date and time of when the last time 
                                            //the inventory was updated
    public string UpdatedBy {get; set;} //Doing research to set a "logged in" user 

    public void UpdateQuantity(int qty) //method to adjust quantities in inventory
    {
        ;
    }

    public void UpdateDetails() //method to update a name, description, or category for an item
    {
        ;
    }

    public override string ToString() //used to output data pertaining to item info
    {
        ;
    }

}