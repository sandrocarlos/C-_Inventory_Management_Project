
public class InventoryManager
{
    List<InventoryItem> items = new List<InventoryItem> (); //list stored in memory
    
    public string ViewItems() //View all items in inventory
    {
        ;
    }

    public string AddItem() //Insert into SQLite db and to list
    {
        ;
    }

    public string RemoveItem() //Delete from SQLite db and list
    {
        ;
    }

    public string UpdateItem() //Modify data in SQLite db and list
    {
        ;
    }

    public string SearchItem() //Query SQLite db to locate an item
    {
        ;
    }

    
}