public class MenuUI
{
    public void ShowMainMenu() //Displays options to navigate to desired menu option
    {
        ;
    }

    public void Add() //Navigates to the menu option to add an item to the db
    {
        ;
    }

    public void Update() //Navigates to the menu option to modify an item in the db
    {
        ;
    }

    public void Remove() //Navigates to the menu option to remove an item in the db
    {
        ;
    
    }

    public void View() //Navigate to the menu option to view all items in db
    {
        ;
    } 
}